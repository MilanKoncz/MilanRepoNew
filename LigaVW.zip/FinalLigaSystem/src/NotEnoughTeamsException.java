
public class NotEnoughTeamsException extends Exception{
	
	public NotEnoughTeamsException(String m) {
		super(m);
	}
}
